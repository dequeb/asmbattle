#CHANGE LOG

##version 0.9.1
* rewrite in tkinter
* build with Cython
* add link to "pay me pizza"
* translation to fr_CA
* bug fixes
* format text in about box
* known issue: menu keyboard shortcuts not working in macOS

##version 0.9
* first beta version
* build with Cython
* missing about box, link to pay me a coffee, help files, icon, etc.
