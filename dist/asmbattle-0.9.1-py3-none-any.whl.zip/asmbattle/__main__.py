from asmbattle import ui_controller

def main():
    ui_controller.main()

ui_controller.main()